# Care Task Template Library

An enterprise, governed **Care Task Template Library** for domiciliary / residential care
providers. It models the full care-delivery chain as four distinct layers:

```
Master Task Template  →  Task Pack  →  Service-User Task Plan  →  Visit Task Instance
   (reusable, governed)   (grouped)     (personalised per person)   (recorded by carers)
```

A template is **not** a live task — it is an approved, versioned blueprint. Templates are
personalised into a service user's plan, then generated into per-visit instances that carers
complete, refuse, miss or flag at the point of care.

Built as a clickable prototype with **Vite + Tailwind CSS v4 + Alpine.js**, a clinical
NHS-inspired design system, and a schema-driven evidence engine.

## Quick start

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build to /dist
npm run preview  # preview the production build
```

## Architecture

| Layer | Location | Purpose |
|---|---|---|
| Design tokens | `src/style.css` | Clinical theme (`@theme`), component utility classes |
| Icons | `src/icons.js` | Inline Lucide-style icon set — `icon(name, classes)` |
| Core libs | `src/lib/` | `dom` (html/esc/map), `router` (hash router), `store`, `overlay` (toast/modal/drawer) |
| Mock data | `src/data/` | Shaped to the data model — templates, packs, service users, tasks, visit instances, alerts, governance |
| Schema engine | `src/data/schemas.js` + `domain.js` | JSON evidence schemas → rendered carer forms |
| UI primitives | `src/components/ui.js` | Buttons, badges, cards, tabs, tables, charts, stats |
| Domain components | `src/components/domain.js` | TemplateCard, EvidenceFormRenderer, AlertRow, WeeklyMatrix, Stepper, BodyMap… |
| App shell | `src/components/shell.js` | Sidebar + topbar + content slot, role switcher |
| Screens | `src/screens/` | One module per route, returns an HTML string |

**Everything is data-driven.** A template carries `evidenceSchema`, `alertRules`,
`completionRules` and `dependencies` as data; the same renderer turns any schema into the
correct carer recording UI (checkbox, number+unit, score, eMAR outcome, body map, signature…).

## Screens (routes)

| Route | Screen |
|---|---|
| `#/` | Dashboard — exceptions, trends, coverage, activity |
| `#/templates` | Template Library — category rail, search, filters, grid/list |
| `#/templates/:id` | Template Detail — purpose, instructions, evidence, versions, governance |
| `#/templates/new` · `/:id/edit` | Create/Edit Template wizard (9 steps) |
| `#/packs` · `/:id` · `/new` | Task Packs — browse, detail, builder |
| `#/apply` | Apply template/pack to a service user (5 steps) |
| `#/service-users` · `/:id/planner` | Service users + Task Planner (By Visit / Category / Weekly Matrix / Exceptions / Care-plan) |
| `#/carer` · `/carer/:visit` | Carer mobile experience + evidence recording sheet |
| `#/exceptions` | Exception Monitor + alert drawer |
| `#/reports` | Reports & Analytics (usage, trends, compliance, CQC evidence) |
| `#/audit` | Audit trail |
| `#/governance` | Approval queue, workflow, versioning rules |
| `#/permissions` | Role-based permissions matrix |

## Build phases (delivered)

- **Phase 0 — Foundation**: scaffold, clinical design system, component library, mock-data layer, app shell, router.
- **Phase 1 — Template Library**: library, detail, create/edit wizard, versioning.
- **Phase 2 — Packs & Apply**: pack builder, apply flow, service-user planner.
- **Phase 3 — Evidence & Monitoring**: schema-driven forms, carer mobile, exception monitor.
- **Phase 4 — Governance & Compliance**: approval workflow, audit trail, reports, CQC evidence, permissions.

> This is a front-end prototype: data is mocked in `src/data/`. No backend is wired up.
