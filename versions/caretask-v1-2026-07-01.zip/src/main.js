import './style.css'
import Alpine from 'alpinejs'

import { route, startRouter, onContentRender, navigate, setNotFound, handleRoute } from './lib/router.js'
import { renderShell, setActiveNav } from './components/shell.js'
import { store } from './lib/store.js'
import { toast, openModal, closeModal, openDrawer, closeDrawer } from './lib/overlay.js'

import { renderDashboard } from './screens/dashboard.js'
import { renderLibrary } from './screens/library.js'
import { renderTemplateDetail } from './screens/templateDetail.js'
import { renderTemplateWizard } from './screens/templateWizard.js'
import { renderPacks, renderPackDetail, renderPackBuilder } from './screens/packs.js'
import { renderApply } from './screens/apply.js'
import { renderServiceUsers } from './screens/serviceUsers.js'
import { renderPlanner, openTaskDrawer } from './screens/planner.js'
import { renderCarer, renderCarerVisit, registerCarerApp } from './screens/carer.js'
import { icon } from './icons.js'
import { catIcon } from './components/domain.js'
import { carerState } from './lib/carerState.js'
import { renderExceptions, openAlertDrawer } from './screens/exceptions.js'
import { renderReports } from './screens/reports.js'
import { renderAudit } from './screens/audit.js'
import { renderGovernance } from './screens/governance.js'
import { renderPermissions } from './screens/permissions.js'
import { notFound } from './screens/notFound.js'

/* ----------------------------------------------------------- Global handlers */
window.__nav = navigate
window.__toast = toast
window.__closeModal = closeModal
window.__closeDrawer = closeDrawer
window.__openModal = openModal
window.__openDrawer = openDrawer
window.__openTask = openTaskDrawer
window.__openAlert = openAlertDrawer

/* carer-app reactive helpers (used inside Alpine x-html / onclick) */
const CARER_STATUS_ICON = { completed: 'check-circle', refused: 'refuse', unable: 'warning', partial: 'info', flagged: 'flag', pending: 'clock' }
window.__icon = (s) => icon(CARER_STATUS_ICON[s] || 'clock', 'w-3.5 h-3.5')
window.__catIcon = (cid) => catIcon(cid, 'w-4 h-4', 'w-8 h-8')
window.__carerSync = () => { carerState.sync(); handleRoute() }
window.__carerReset = () => { carerState.reset(); handleRoute(); toast('Carer demo data reset', 'info') }
window.__setRole = (role) => {
  store.set('role', role)
  renderShell()
  setActiveNav(location.hash.slice(1) || '/')
  // re-init Alpine + re-render content
  Alpine.initTree(document.getElementById('app'))
  handleRoute()
  toast(`Now acting as ${role}`, 'info')
}
window.__notify = (msg, type = 'success') => toast(msg, type)

/* ------------------------------------------------------------------ Routes */
route('/', renderDashboard)
route('/templates', renderLibrary)
route('/templates/new', renderTemplateWizard)
route('/templates/:id/edit', renderTemplateWizard)
route('/templates/:id', renderTemplateDetail)
route('/packs', renderPacks)
route('/packs/new', renderPackBuilder)
route('/packs/:id', renderPackDetail)
route('/apply', renderApply)
route('/service-users', renderServiceUsers)
route('/service-users/:id/planner', renderPlanner)
route('/carer', renderCarer)
route('/carer/:visit', renderCarerVisit)
route('/exceptions', renderExceptions)
route('/reports', renderReports)
route('/audit', renderAudit)
route('/governance', renderGovernance)
route('/permissions', renderPermissions)
setNotFound(notFound)

/* ------------------------------------------------------------------ Boot */
renderShell()
onContentRender((view, _r, ctx) => {
  const slot = document.getElementById('route-content')
  slot.innerHTML = view
  setActiveNav((location.hash.slice(1) || '/'))
})

window.Alpine = Alpine
registerCarerApp(Alpine)
Alpine.start()
startRouter()
