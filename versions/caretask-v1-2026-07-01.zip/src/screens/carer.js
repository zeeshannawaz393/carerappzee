import { html, esc, map } from '../lib/dom.js'
import { page } from './_layout.js'
import { icon } from '../icons.js'
import { pageHeader, btn, badge, sectionCard, priorityBadge } from '../components/ui.js'
import { catIcon } from '../components/domain.js'
import { getServiceUser, tasksForUser, VISIT_BLOCKS, category, getTemplate, TEMPLATE_TYPES } from '../data/index.js'
import { carerState, visitProgress, blockingTasks } from '../lib/carerState.js'

const SU = 'su-mary'
const REQUIRED_RULES = ['essential', 'critical', 'required_before_visit', 'manager_review']

/* ---------------------------------------------------------------- Model */
/** Build the static definition for one visit: service user + augmented tasks. */
function buildVisitModel(visitName) {
  const block = VISIT_BLOCKS.find((v) => v.visit.toLowerCase() === visitName) || VISIT_BLOCKS[0]
  const su = getServiceUser(SU)
  const tasks = tasksForUser(SU)
    .filter((t) => t.visit === block.visit)
    .map((t) => {
      const tpl = getTemplate(t.sourceTemplateId)
      const fields = (tpl?.evidenceSchema?.fields || []).map((f) => ({
        ...f,
        range: f.type === 'score' ? Array.from({ length: (f.max ?? 5) - (f.min ?? 0) + 1 }, (_, i) => (f.min ?? 0) + i) : undefined,
      }))
      return {
        id: t.id,
        title: t.title,
        categoryId: t.categoryId,
        type: t.type,
        typeLabel: TEMPLATE_TYPES[t.type]?.label || 'Task',
        priority: t.priority,
        instructions: t.instructions,
        why: tpl?.purpose || tpl?.description || '',
        dosDonts: tpl?.instructions?.dosDonts || [],
        isMed: t.type === 'medication',
        required: REQUIRED_RULES.includes(tpl?.completionRule) || ['essential', 'critical'].includes(t.priority),
        fields,
      }
    })
  return { block, su, tasks }
}

/* ------------------------------------------------------- Alpine component */
export function registerCarerApp(Alpine) {
  Alpine.data('carerVisit', (visitName) => ({
    view: 'tasks',
    visit: visitName,
    block: {},
    su: {},
    taskDefs: [],
    tasks: [],
    clock: { clockIn: null, clockOut: null },
    note: '',
    queued: 0,
    // evidence sheet
    activeId: null,
    form: {},
    outcome: '',
    errors: [],
    // concern sheet
    concernText: '',
    concernSeverity: 'medium',

    init() {
      const m = buildVisitModel(this.visit)
      this.block = m.block
      this.su = m.su
      this.taskDefs = m.tasks
      this.clock = carerState.getVisit(this.visit)
      this.note = carerState.getNote(this.visit)
      this.queued = carerState.queuedCount()
      this.refresh()
    },
    refresh() {
      this.tasks = this.taskDefs.map((t) => ({ ...t, record: carerState.getRecord(this.visit, t.id) }))
    },

    /* ---- computed ---- */
    get progress() {
      const total = this.tasks.length
      const done = this.tasks.filter((t) => t.record).length
      return { done, total, pct: total ? Math.round((done / total) * 100) : 0 }
    },
    get blocking() {
      return this.tasks.filter((t) => t.required && !t.record)
    },
    get canClockOut() {
      return !!this.clock.clockIn && this.blocking.length === 0
    },
    get activeTask() {
      return this.tasks.find((t) => t.id === this.activeId) || null
    },
    get requiredTasks() {
      return this.tasks.filter((t) => t.required)
    },
    get optionalTasks() {
      return this.tasks.filter((t) => !t.required)
    },

    /* ---- status helpers ---- */
    statusOf(t) {
      return t.record ? t.record.status : 'pending'
    },
    statusIcon(s) {
      return { completed: 'check-circle', refused: 'refuse', unable: 'warning', partial: 'info', flagged: 'flag', pending: 'clock' }[s] || 'clock'
    },
    statusColor(s) {
      return { completed: 'text-success-600', refused: 'text-danger-600', unable: 'text-warning-600', partial: 'text-warning-600', flagged: 'text-danger-600', pending: 'text-ink-300' }[s] || 'text-ink-300'
    },

    /* ---- clock ---- */
    clockInNow() {
      this.clock = carerState.clockIn(this.visit)
      window.__notify(`Clocked in to ${this.block.visit} visit`, 'success')
    },
    confirmClockOut() {
      if (!this.canClockOut) {
        window.__notify('Record all required tasks before clock-out', 'warning')
        this.view = 'tasks'
        return
      }
      this.clock = carerState.clockOut(this.visit)
      window.__notify(`Visit complete — clocked out at ${this.clock.clockOut}`, 'success')
      this.view = 'tasks'
    },

    /* ---- evidence sheet ---- */
    openTask(id) {
      this.activeId = id
      this.errors = []
      const t = this.activeTask
      const existing = t?.record
      this.form = existing ? { ...existing.evidence } : this.defaultForm(t)
      this.outcome = existing ? existing.outcomeRaw || '' : t.isMed ? '' : 'Completed'
      this.view = 'evidence'
    },
    defaultForm(t) {
      const f = {}
      ;(t?.fields || []).forEach((field) => {
        if (field.type === 'checklist') f[field.key] = []
        else if (field.type === 'datetime') f[field.key] = this.clock.clockIn || '07:35'
        else if (field.type === 'bodymap') f[field.key] = []
        else f[field.key] = ''
      })
      return f
    },
    fieldNeeded(f) {
      if (f.required) return true
      if (f.requiredIf) return this.evalCond(f.requiredIf)
      return false
    },
    evalCond(expr) {
      try {
        let m
        if ((m = expr.match(/^(\w+)\s+in\s+\[(.*)\]$/))) {
          const list = m[2].split(',').map((s) => s.trim().replace(/^['"]|['"]$/g, ''))
          return list.includes(String(this.form[m[1]]))
        }
        if ((m = expr.match(/^(\w+)\s*(==|!=)\s*(.+)$/))) {
          let rhs = m[3].trim().replace(/^['"]|['"]$/g, '')
          const v = this.form[m[1]]
          if (rhs === 'true' || rhs === 'false') {
            const vb = v === true || v === 'true'
            return m[2] === '==' ? vb === (rhs === 'true') : vb !== (rhs === 'true')
          }
          return m[2] === '==' ? String(v) === rhs : String(v) !== rhs
        }
      } catch {
        /* noop */
      }
      return false
    },
    hasValue(f) {
      const v = this.form[f.key]
      if (Array.isArray(v)) return v.length > 0
      return v !== '' && v !== null && v !== undefined
    },
    setBool(key, val) {
      this.form[key] = val
    },
    setScore(key, val) {
      this.form[key] = val
    },
    toggleCheck(key, opt) {
      if (!Array.isArray(this.form[key])) this.form[key] = []
      const i = this.form[key].indexOf(opt)
      i > -1 ? this.form[key].splice(i, 1) : this.form[key].push(opt)
    },
    toggleBodyMark(region) {
      if (!Array.isArray(this.form.bodymap)) this.form.bodymap = []
      const i = this.form.bodymap.indexOf(region)
      i > -1 ? this.form.bodymap.splice(i, 1) : this.form.bodymap.push(region)
    },
    sign(key) {
      this.form[key] = `Aisha Khan · ${this.clock.clockIn || '07:35'}`
    },
    addPhoto(key) {
      this.form[key] = 'photo_2026-06-30.jpg'
    },

    validate() {
      const t = this.activeTask
      const errs = []
      if (!t.isMed && !this.outcome) errs.push('Choose an outcome.')
      t.fields.forEach((f) => {
        if (this.fieldNeeded(f) && !this.hasValue(f)) errs.push(`"${f.label}" is required.`)
      })
      if (!t.isMed && ['Refused', 'Unable', 'Partial'].includes(this.outcome)) {
        const hasReason = this.hasValue({ key: 'reason' }) || this.hasValue({ key: 'note' })
        if (!hasReason) errs.push('Add a reason / note for this outcome.')
      }
      this.errors = errs
      return errs.length === 0
    },
    deriveStatus(t) {
      let status = 'completed'
      let outcomeRaw = this.outcome
      if (t.isMed) {
        outcomeRaw = this.form.outcome || ''
        status = { Given: 'completed', Refused: 'refused', 'Not available': 'unable', Withheld: 'unable', 'Partially taken': 'partial' }[outcomeRaw] || 'completed'
      } else {
        status = { Completed: 'completed', Refused: 'refused', Unable: 'unable', Partial: 'partial' }[this.outcome] || 'completed'
      }
      const flagged = this.form.concern === true || this.form.escalate === true ||
        (this.form.condition && !['Intact / healthy'].includes(this.form.condition)) ||
        (this.form.skin && ['Red', 'Sore', 'Broken'].includes(this.form.skin))
      if (flagged && status === 'completed') status = 'flagged'
      return { status, outcomeRaw, flagged }
    },
    saveTask() {
      const t = this.activeTask
      if (!this.validate()) {
        window.__notify('Please complete the required fields', 'warning')
        return
      }
      const { status, outcomeRaw, flagged } = this.deriveStatus(t)
      const label = { completed: 'Completed', refused: 'Refused', unable: 'Unable', partial: 'Partial', flagged: 'Flagged — concern raised' }[status]
      carerState.saveRecord(this.visit, t.id, { status, outcomeRaw, outcomeLabel: label, evidence: { ...this.form } })
      this.queued = carerState.queuedCount()
      this.refresh()
      this.view = 'tasks'
      if (flagged || status === 'refused') {
        window.__notify(`Office alerted: ${t.title} — ${label}`, 'warning')
      } else {
        window.__notify(`Saved: ${t.title}`, 'success')
      }
    },

    /* ---- concern ---- */
    submitConcern() {
      if (!this.concernText.trim()) {
        window.__notify('Add a short description of the concern', 'warning')
        return
      }
      window.__notify(`${this.concernSeverity.toUpperCase()} concern raised to office — ${this.su.name}`, 'warning')
      this.concernText = ''
      this.view = 'tasks'
    },

    /* ---- notes / sync / reset ---- */
    saveNote() {
      carerState.setNote(this.visit, this.note)
      window.__notify('Visit note saved', 'success')
    },
    syncNow() {
      carerState.sync()
      this.queued = 0
      window.__notify('All records synced to office', 'success')
    },
    resetDemo() {
      carerState.reset()
      this.clock = { clockIn: null, clockOut: null }
      this.note = ''
      this.queued = 0
      this.refresh()
      this.view = 'tasks'
      window.__notify('Carer demo data reset', 'info')
    },
  }))
}

/* keep main.js import stable (legacy export) */
export function openEvidenceSheet() {}

/* --------------------------------------------------------- Phone frame */
function phone(inner, { scroll = true } = {}) {
  return html`
    <div class="mx-auto" style="max-width:420px">
      <div class="rounded-[2.25rem] bg-ink-900 p-3 shadow-2xl">
        <div class="rounded-[1.75rem] bg-canvas overflow-hidden h-[780px] flex flex-col relative">
          <div class="absolute top-0 inset-x-0 h-7 flex items-center justify-center z-30 pointer-events-none"><span class="w-24 h-5 bg-ink-900 rounded-b-2xl"></span></div>
          ${inner}
        </div>
      </div>
    </div>`
}

/* --------------------------------------------------------- Home screen */
export function renderCarer() {
  const su = getServiceUser(SU)
  const visits = VISIT_BLOCKS.map((v) => {
    const key = v.visit.toLowerCase()
    const m = buildVisitModel(key)
    const prog = visitProgress(key, m.tasks)
    const clock = carerState.getVisit(key)
    const block = blockingTasks(key, m.tasks)
    const status = clock.clockOut ? 'Completed' : clock.clockIn ? 'In progress' : 'Upcoming'
    return { ...v, key, prog, clock, status, blocking: block.length, total: m.tasks.length }
  })
  const queued = carerState.queuedCount()

  const inner = html`
    <div class="flex flex-col h-full" x-data="{}">
      <div class="bg-primary-700 text-white px-5 pt-9 pb-5">
        <div class="flex items-center justify-between">
          <div>
            <p class="text-xs text-primary-100">Tuesday, 30 June 2026</p>
            <h2 class="text-lg font-bold mt-0.5">Your visits today</h2>
          </div>
          <span class="w-10 h-10 rounded-full bg-primary-600 grid place-items-center text-sm font-semibold ring-2 ring-primary-400">AK</span>
        </div>
        <p class="text-sm text-primary-100 mt-1">Aisha Khan · Riverside Care</p>
      </div>

      <!-- offline / sync banner -->
      <div class="px-4 pt-3">
        <div class="rounded-xl ${queued ? 'bg-warning-50 ring-warning-100' : 'bg-success-50 ring-success-100'} ring-1 p-3 flex items-center gap-3">
          <span class="${queued ? 'text-warning-600' : 'text-success-600'}">${icon(queued ? 'clock' : 'check-circle', 'w-5 h-5')}</span>
          <div class="flex-1 min-w-0">
            <p class="text-[13px] font-semibold ${queued ? 'text-warning-800' : 'text-success-800'}">${queued ? `${queued} record${queued > 1 ? 's' : ''} queued offline` : 'All records synced'}</p>
            <p class="text-[11px] ${queued ? 'text-warning-700' : 'text-success-700'}">Point-of-care recording works offline.</p>
          </div>
          ${queued ? `<button onclick="window.__carerSync && window.__carerSync()" class="btn btn-secondary btn-sm">${icon('refresh', 'w-3.5 h-3.5')}Sync</button>` : ''}
        </div>
      </div>

      <div class="flex-1 overflow-y-auto p-4 space-y-3">
        ${map(visits, (v) => {
          const tone = v.status === 'Completed' ? 'success' : v.status === 'In progress' ? 'warning' : 'ink'
          return html`<a href="#/carer/${v.key}" class="block card p-4 active:scale-[.99] transition-transform">
            <div class="flex items-center gap-3">
              <span class="w-11 h-11 rounded-xl bg-primary-100 text-primary-700 grid place-items-center font-semibold text-sm">${su.initials}</span>
              <div class="flex-1 min-w-0">
                <p class="text-sm font-semibold text-ink-900">${esc(su.name)}</p>
                <p class="text-xs text-ink-400">${esc(v.visit)} · ${esc(v.time)}</p>
              </div>
              ${badge(v.status, tone === 'success' ? 'bg-success-50 text-success-700 ring-success-100' : tone === 'warning' ? 'bg-warning-50 text-warning-700 ring-warning-100' : 'bg-ink-100 text-ink-500 ring-ink-200')}
            </div>
            <div class="mt-3 flex items-center gap-3">
              <div class="flex-1 h-1.5 rounded-full bg-ink-100 overflow-hidden"><div class="h-1.5 ${v.prog.pct === 100 ? 'bg-success-500' : 'bg-primary-500'} rounded-full" style="width:${v.prog.pct}%"></div></div>
              <span class="text-[11px] font-medium text-ink-500">${v.prog.done}/${v.prog.total}</span>
            </div>
            ${v.clock.clockIn && v.blocking ? `<p class="text-[11px] text-danger-600 mt-2 flex items-center gap-1">${icon('alert', 'w-3 h-3')}${v.blocking} required task${v.blocking > 1 ? 's' : ''} before clock-out</p>` : ''}
          </a>`
        })}
      </div>

      <div class="p-3 border-t border-ink-200 bg-surface flex items-center justify-between">
        <p class="text-[11px] text-ink-400">v2.4 · synced 07:30</p>
        <button onclick="window.__carerReset && window.__carerReset()" class="text-[11px] text-ink-400 hover:text-danger-600 flex items-center gap-1">${icon('refresh', 'w-3 h-3')}Reset demo</button>
      </div>
    </div>`

  return page(html`
    ${pageHeader({ title: 'Carer mobile app', subtitle: 'Point-of-care recording generated from the service-user task plan — fully working, persisted, offline-ready.', breadcrumbs: [{ label: 'Carer App' }] })}
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
      ${phone(inner)}
      <div class="space-y-4 max-w-md" x-data="{}">
        ${sectionCard({ title: 'A working point-of-care app', icon: 'mobile', body: html`<ul class="space-y-3 text-sm text-ink-600">
          <li class="flex gap-2.5">${icon('check-circle', 'w-4 h-4 text-primary-500 mt-0.5 shrink-0')}<span><b>Clock in</b> to a visit, work through the tasks, then <b>clock out</b> — blocked until required & medication tasks are recorded.</span></li>
          <li class="flex gap-2.5">${icon('file-check', 'w-4 h-4 text-primary-500 mt-0.5 shrink-0')}<span>Each task opens a <b>schema-driven evidence form</b> (ml, score, eMAR outcome, checklist, body map, signature) with real <b>required-field validation</b>.</span></li>
          <li class="flex gap-2.5">${icon('flag', 'w-4 h-4 text-primary-500 mt-0.5 shrink-0')}<span>Refusals and concerns <b>raise office alerts</b>; everything <b>persists</b> (localStorage) and survives reload.</span></li>
        </ul>` })}
        <div class="flex gap-2">
          ${btn('Open Morning visit', { href: '#/carer/morning', icon: 'arrow-right' })}
          ${btn('Tea visit', { href: '#/carer/tea', variant: 'secondary' })}
        </div>
      </div>
    </div>
  `)
}

/* --------------------------------------------------------- Visit app */
export function renderCarerVisit({ visit }) {
  const v = (visit || 'morning').toLowerCase()

  const inner = html`
    <div class="flex flex-col h-full" x-data="carerVisit('${v}')" x-init="init()">

      <!-- header -->
      <div class="bg-primary-700 text-white px-5 pt-9 pb-4 shrink-0">
        <div class="flex items-center justify-between">
          <a href="#/carer" class="inline-flex items-center gap-1 text-xs text-primary-100">${icon('chevron-left', 'w-4 h-4')}Visits</a>
          <button @click="view='context'" class="text-xs text-primary-100 inline-flex items-center gap-1">${icon('info', 'w-3.5 h-3.5')}About</button>
        </div>
        <h2 class="text-lg font-bold mt-1.5" x-text="su.name"></h2>
        <p class="text-sm text-primary-100"><span x-text="block.visit"></span> Visit · <span x-text="block.time"></span></p>
        <!-- clock + progress -->
        <div class="mt-3 flex items-center gap-3">
          <template x-if="!clock.clockIn">
            <button @click="clockInNow()" class="btn btn-md w-full !bg-white !text-primary-700 hover:!bg-primary-50">${icon('clock', 'w-4 h-4')}Clock in to start visit</button>
          </template>
          <template x-if="clock.clockIn">
            <div class="flex-1 flex items-center gap-3">
              <div class="flex-1">
                <div class="flex justify-between text-[11px] text-primary-100 mb-1"><span x-text="clock.clockIn ? ('In '+clock.clockIn) : ''"></span><span x-text="progress.done+'/'+progress.total+' done'"></span></div>
                <div class="h-1.5 rounded-full bg-primary-900/40 overflow-hidden"><div class="h-1.5 bg-white rounded-full transition-all" :style="'width:'+progress.pct+'%'"></div></div>
              </div>
            </div>
          </template>
        </div>
      </div>

      <!-- ============ TASKS VIEW ============ -->
      <div x-show="view==='tasks'" class="flex-1 overflow-y-auto p-4 space-y-4">
        <!-- required -->
        <div>
          <p class="text-xs font-semibold uppercase tracking-wide text-ink-400 mb-2">Required tasks</p>
          <div class="space-y-2.5">
            <template x-for="t in requiredTasks" :key="t.id">
              <button @click="openTask(t.id)" class="w-full text-left card p-3.5 flex items-center gap-3 active:scale-[.99] transition-transform">
                <span class="w-6 h-6 rounded-md grid place-items-center shrink-0"
                  :class="statusOf(t)==='completed' ? 'bg-success-500 text-white' : statusOf(t)==='pending' ? 'ring-1 ring-ink-300' : (statusOf(t)==='partial' ? 'bg-warning-500 text-white' : 'bg-danger-500 text-white')">
                  <span x-show="statusOf(t)!=='pending'" x-html="window.__icon(statusOf(t))"></span>
                </span>
                <span x-html="window.__catIcon(t.categoryId)"></span>
                <span class="min-w-0 flex-1">
                  <span class="block text-sm font-semibold text-ink-900" :class="statusOf(t)==='completed' && 'line-through text-ink-400'" x-text="t.title"></span>
                  <span class="block text-xs" :class="t.record ? 'text-ink-400' : 'text-ink-400'">
                    <span x-show="t.record" class="font-medium" :class="statusColor(statusOf(t))" x-text="t.record ? t.record.outcomeLabel : ''"></span>
                    <span x-show="!t.record" x-text="t.typeLabel"></span>
                  </span>
                </span>
                <span x-show="t.isMed" class="badge bg-danger-50 text-danger-700 ring-danger-100">eMAR</span>
                <span class="text-ink-300">${icon('chevron-right', 'w-4 h-4')}</span>
              </button>
            </template>
          </div>
        </div>
        <!-- optional -->
        <div x-show="optionalTasks.length">
          <p class="text-xs font-semibold uppercase tracking-wide text-ink-400 mb-2">Optional</p>
          <div class="space-y-2.5">
            <template x-for="t in optionalTasks" :key="t.id">
              <button @click="openTask(t.id)" class="w-full text-left card p-3.5 flex items-center gap-3 active:scale-[.99] transition-transform">
                <span class="w-6 h-6 rounded-md grid place-items-center shrink-0"
                  :class="statusOf(t)==='completed' ? 'bg-success-500 text-white' : statusOf(t)==='pending' ? 'ring-1 ring-ink-300' : 'bg-danger-500 text-white'">
                  <span x-show="statusOf(t)!=='pending'" x-html="window.__icon(statusOf(t))"></span>
                </span>
                <span x-html="window.__catIcon(t.categoryId)"></span>
                <span class="min-w-0 flex-1">
                  <span class="block text-sm font-semibold text-ink-900" :class="statusOf(t)==='completed' && 'line-through text-ink-400'" x-text="t.title"></span>
                  <span class="block text-xs text-ink-400" x-text="t.record ? t.record.outcomeLabel : t.typeLabel"></span>
                </span>
                <span class="text-ink-300">${icon('chevron-right', 'w-4 h-4')}</span>
              </button>
            </template>
          </div>
        </div>

        <!-- report concern + notes -->
        <button @click="view='concern'" class="w-full card p-3.5 flex items-center gap-3 text-left active:scale-[.99]">
          <span class="w-9 h-9 rounded-lg bg-danger-50 text-danger-600 grid place-items-center">${icon('flag', 'w-4.5 h-4.5')}</span>
          <div class="flex-1"><p class="text-sm font-semibold text-ink-900">Report a concern</p><p class="text-xs text-ink-400">Raise a safeguarding or care concern to the office</p></div>
          <span class="text-ink-300">${icon('chevron-right', 'w-4 h-4')}</span>
        </button>

        <div class="card p-3.5">
          <label class="text-sm font-semibold text-ink-900 flex items-center gap-2 mb-2">${icon('edit', 'w-4 h-4 text-ink-400')}Visit note / handover</label>
          <textarea x-model="note" rows="2" class="field px-3 py-2 text-sm" placeholder="Anything to hand over…"></textarea>
          <button @click="saveNote()" class="btn btn-secondary btn-sm mt-2">${icon('check', 'w-3.5 h-3.5')}Save note</button>
        </div>
      </div>

      <!-- ============ EVIDENCE SHEET ============ -->
      <div x-show="view==='evidence'" x-cloak class="flex-1 flex flex-col overflow-hidden">
        <template x-if="activeTask">
          <div class="flex flex-col h-full">
            <div class="px-4 py-3 border-b border-ink-100 bg-surface flex items-center gap-2 shrink-0">
              <button @click="view='tasks'" class="btn btn-ghost btn-sm !px-2">${icon('chevron-left', 'w-5 h-5')}</button>
              <div class="min-w-0 flex-1"><p class="text-sm font-semibold text-ink-900 truncate" x-text="activeTask.title"></p><p class="text-xs text-ink-400" x-text="activeTask.typeLabel"></p></div>
            </div>
            <div class="flex-1 overflow-y-auto p-4 space-y-4">
              <!-- what / why -->
              <div class="rounded-xl bg-primary-50 ring-1 ring-primary-100 p-3.5">
                <p class="text-xs font-semibold text-primary-700 uppercase tracking-wide mb-1">What to do</p>
                <p class="text-sm text-primary-900" x-text="activeTask.instructions"></p>
              </div>
              <div x-show="activeTask.why" class="rounded-xl bg-teal-50 ring-1 ring-teal-100 p-3.5">
                <p class="text-xs font-semibold text-teal-700 uppercase tracking-wide mb-1">Why</p>
                <p class="text-sm text-teal-900" x-text="activeTask.why"></p>
              </div>

              <!-- errors -->
              <div x-show="errors.length" x-cloak class="rounded-xl bg-danger-50 ring-1 ring-danger-100 p-3">
                <p class="text-xs font-semibold text-danger-700 mb-1 flex items-center gap-1.5">${icon('alert', 'w-3.5 h-3.5')}Please fix:</p>
                <ul class="text-[13px] text-danger-800 list-disc pl-5 space-y-0.5"><template x-for="e in errors" :key="e"><li x-text="e"></li></template></ul>
              </div>

              <!-- outcome (non-medication) -->
              <div x-show="!activeTask.isMed">
                <p class="label">Outcome <span class="text-danger-500">*</span></p>
                <div class="grid grid-cols-4 gap-1.5">
                  <template x-for="o in ['Completed','Partial','Refused','Unable']" :key="o">
                    <button type="button" @click="outcome=o"
                      :class="outcome===o ? (o==='Completed' ? 'bg-success-600 text-white ring-success-600' : o==='Partial' ? 'bg-warning-500 text-white ring-warning-500' : 'bg-danger-500 text-white ring-danger-500') : 'bg-white text-ink-600 ring-ink-200'"
                      class="h-10 rounded-lg ring-1 text-xs font-semibold" x-text="o"></button>
                  </template>
                </div>
              </div>

              <!-- schema fields -->
              <p class="text-xs font-semibold text-ink-400 uppercase tracking-wide pt-1">Record</p>
              <template x-for="f in activeTask.fields" :key="f.key">
                <div x-show="!f.requiredIf || true">
                  <label class="label" x-text="f.label + (fieldNeeded(f) ? ' *' : '')"></label>

                  <!-- boolean -->
                  <template x-if="f.type==='boolean'">
                    <div class="flex gap-2">
                      <button type="button" @click="setBool(f.key,true)" :class="form[f.key]===true ? 'bg-success-50 ring-success-300 text-success-700' : 'bg-white ring-ink-200 text-ink-600'" class="btn-sm flex-1 rounded-lg ring-1 h-10 inline-flex items-center justify-center gap-1.5 font-semibold">${icon('check', 'w-4 h-4')}Yes</button>
                      <button type="button" @click="setBool(f.key,false)" :class="form[f.key]===false ? 'bg-danger-50 ring-danger-300 text-danger-700' : 'bg-white ring-ink-200 text-ink-600'" class="btn-sm flex-1 rounded-lg ring-1 h-10 inline-flex items-center justify-center gap-1.5 font-semibold">${icon('x', 'w-4 h-4')}No</button>
                    </div>
                  </template>

                  <!-- select -->
                  <template x-if="f.type==='select'">
                    <select x-model="form[f.key]" class="field field-md"><option value="">Select…</option><template x-for="o in f.options" :key="o"><option :value="o" x-text="o"></option></template></select>
                  </template>

                  <!-- checklist -->
                  <template x-if="f.type==='checklist'">
                    <div class="space-y-1.5">
                      <template x-for="o in f.options" :key="o">
                        <button type="button" @click="toggleCheck(f.key,o)" :class="(form[f.key]||[]).includes(o) ? 'ring-primary-400 bg-primary-50' : 'ring-ink-200'" class="w-full flex items-center gap-2.5 p-2.5 rounded-lg ring-1 text-left">
                          <span class="w-5 h-5 rounded grid place-items-center shrink-0" :class="(form[f.key]||[]).includes(o) ? 'bg-primary-600 text-white' : 'ring-1 ring-ink-300'"><span x-show="(form[f.key]||[]).includes(o)">${icon('check', 'w-3.5 h-3.5')}</span></span>
                          <span class="text-sm text-ink-700" x-text="o"></span>
                        </button>
                      </template>
                    </div>
                  </template>

                  <!-- number -->
                  <template x-if="f.type==='number'">
                    <div class="relative">
                      <input type="number" :min="f.min" :max="f.max" x-model.number="form[f.key]" class="field field-md" :class="f.unit && 'pr-14'" placeholder="0" />
                      <span x-show="f.unit" class="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-ink-400" x-text="f.unit"></span>
                    </div>
                  </template>

                  <!-- score -->
                  <template x-if="f.type==='score'">
                    <div class="flex flex-wrap gap-1.5">
                      <template x-for="s in f.range" :key="s">
                        <button type="button" @click="setScore(f.key,s)" :class="form[f.key]===s ? 'bg-primary-600 text-white ring-primary-600' : 'ring-ink-200 text-ink-600'" class="w-9 h-9 rounded-lg ring-1 text-sm font-semibold" x-text="s"></button>
                      </template>
                    </div>
                  </template>

                  <!-- textarea -->
                  <template x-if="f.type==='textarea'">
                    <textarea x-model="form[f.key]" rows="3" class="field px-3 py-2" placeholder="Type a note…"></textarea>
                  </template>

                  <!-- text -->
                  <template x-if="f.type==='text'">
                    <input type="text" x-model="form[f.key]" class="field field-md" placeholder="…" />
                  </template>

                  <!-- datetime -->
                  <template x-if="f.type==='datetime'">
                    <input type="time" x-model="form[f.key]" class="field field-md" />
                  </template>

                  <!-- signature -->
                  <template x-if="f.type==='signature'">
                    <button type="button" @click="sign(f.key)" class="w-full h-16 rounded-lg ring-1 ring-dashed grid place-items-center text-sm" :class="form[f.key] ? 'ring-success-300 bg-success-50 text-success-700' : 'ring-ink-300 bg-ink-50/50 text-ink-400'">
                      <span x-show="!form[f.key]" class="inline-flex items-center gap-2">${icon('signature', 'w-5 h-5')}Tap to sign</span>
                      <span x-show="form[f.key]" class="inline-flex items-center gap-2 font-medium">${icon('check-circle', 'w-5 h-5')}<span x-text="form[f.key]"></span></span>
                    </button>
                  </template>

                  <!-- photo -->
                  <template x-if="f.type==='photo'">
                    <button type="button" @click="addPhoto(f.key)" class="w-full h-14 rounded-lg ring-1 ring-dashed grid place-items-center text-sm" :class="form[f.key] ? 'ring-success-300 bg-success-50 text-success-700' : 'ring-ink-300 bg-ink-50/50 text-ink-400'">
                      <span class="inline-flex items-center gap-2"><span x-show="!form[f.key]">${icon('eye', 'w-5 h-5')}Add photo</span><span x-show="form[f.key]" x-text="form[f.key]"></span></span>
                    </button>
                  </template>

                  <!-- body map -->
                  <template x-if="f.type==='bodymap'">
                    <div class="rounded-lg ring-1 ring-ink-200 bg-ink-50/40 p-3 flex flex-col items-center">
                      <svg viewBox="0 0 120 240" class="h-44">
                        <g fill="#dce1e9" stroke="#94a0b1" stroke-width="1.5">
                          <circle cx="60" cy="24" r="16"/><rect x="44" y="42" width="32" height="70" rx="12"/>
                          <rect x="26" y="48" width="16" height="56" rx="8"/><rect x="78" y="48" width="16" height="56" rx="8"/>
                          <rect x="46" y="112" width="13" height="80" rx="7"/><rect x="61" y="112" width="13" height="80" rx="7"/>
                        </g>
                        <template x-for="pt in [{r:'Head',x:60,y:24},{r:'Sacrum',x:60,y:100},{r:'L heel',x:52,y:188},{r:'R heel',x:68,y:188},{r:'L hip',x:46,y:96},{r:'R hip',x:74,y:96}]" :key="pt.r">
                          <circle :cx="pt.x" :cy="pt.y" r="7" class="cursor-pointer" :fill="(form.bodymap||[]).includes(pt.r) ? '#d4351c' : 'transparent'" :stroke="(form.bodymap||[]).includes(pt.r) ? '#d4351c' : '#94a0b1'" stroke-width="1.5" @click="toggleBodyMark(pt.r)"></circle>
                        </template>
                      </svg>
                      <p class="text-[11px] text-ink-400 mt-1">Tap an area to mark a concern <span x-show="(form.bodymap||[]).length" class="text-danger-600 font-medium" x-text="'· '+(form.bodymap||[]).join(', ')"></span></p>
                    </div>
                  </template>
                </div>
              </template>
            </div>
            <div class="p-4 border-t border-ink-200 bg-surface shrink-0">
              <button @click="saveTask()" class="btn btn-primary btn-lg w-full">${icon('check', 'w-5 h-5')}Save record</button>
            </div>
          </div>
        </template>
      </div>

      <!-- ============ CONTEXT (About) ============ -->
      <div x-show="view==='context'" x-cloak class="flex-1 overflow-y-auto p-4 space-y-3">
        <div class="flex items-center gap-2"><button @click="view='tasks'" class="btn btn-ghost btn-sm !px-2">${icon('chevron-left', 'w-5 h-5')}</button><p class="text-sm font-semibold text-ink-900">About <span x-text="su.name"></span></p></div>
        <div class="card p-3.5">
          <p class="text-xs font-semibold text-danger-700 uppercase tracking-wide mb-1.5 flex items-center gap-1.5">${icon('alert', 'w-3.5 h-3.5')}Allergies</p>
          <div class="flex flex-wrap gap-1.5"><template x-for="a in su.allergies" :key="a"><span class="badge bg-danger-50 text-danger-700 ring-danger-100" x-text="a"></span></template></div>
        </div>
        <div class="card p-3.5">
          <p class="text-xs font-semibold text-warning-700 uppercase tracking-wide mb-1.5">Active risks</p>
          <div class="flex flex-wrap gap-1.5"><template x-for="r in su.risks" :key="r"><span class="badge bg-warning-50 text-warning-700 ring-warning-100" x-text="r"></span></template></div>
        </div>
        <div class="card p-3.5"><p class="text-xs font-semibold text-ink-400 uppercase tracking-wide mb-1">About me</p><p class="text-sm text-ink-700" x-text="su.aboutMe"></p></div>
        <div class="card p-3.5"><p class="text-xs font-semibold text-ink-400 uppercase tracking-wide mb-1">Access</p><p class="text-sm text-ink-700" x-text="su.access"></p></div>
        <div class="card p-3.5 flex items-center gap-3">
          <span class="w-9 h-9 rounded-lg bg-primary-50 text-primary-600 grid place-items-center">${icon('bell', 'w-4.5 h-4.5')}</span>
          <div class="flex-1 min-w-0"><p class="text-xs font-semibold text-ink-400 uppercase tracking-wide">Emergency contact</p><p class="text-sm text-ink-700 truncate" x-text="su.emergencyContact"></p></div>
          <button @click="window.__notify('Calling emergency contact…','info')" class="btn btn-secondary btn-sm">${icon('bell', 'w-3.5 h-3.5')}Call</button>
        </div>
      </div>

      <!-- ============ CONCERN ============ -->
      <div x-show="view==='concern'" x-cloak class="flex-1 overflow-y-auto p-4 space-y-3">
        <div class="flex items-center gap-2"><button @click="view='tasks'" class="btn btn-ghost btn-sm !px-2">${icon('chevron-left', 'w-5 h-5')}</button><p class="text-sm font-semibold text-ink-900">Report a concern</p></div>
        <div class="card p-3.5 space-y-3">
          <div>
            <p class="label">Severity</p>
            <div class="grid grid-cols-3 gap-1.5">
              <template x-for="s in ['low','medium','high']" :key="s">
                <button @click="concernSeverity=s" :class="concernSeverity===s ? (s==='high' ? 'bg-danger-500 text-white ring-danger-500' : s==='medium' ? 'bg-warning-500 text-white ring-warning-500' : 'bg-success-600 text-white ring-success-600') : 'bg-white text-ink-600 ring-ink-200'" class="h-10 rounded-lg ring-1 text-xs font-semibold capitalize" x-text="s"></button>
              </template>
            </div>
          </div>
          <div><p class="label">What happened?</p><textarea x-model="concernText" rows="4" class="field px-3 py-2" placeholder="Describe the concern for the office…"></textarea></div>
          <button @click="submitConcern()" class="btn btn-danger btn-lg w-full">${icon('flag', 'w-5 h-5')}Raise to office</button>
        </div>
      </div>

      <!-- footer clock-out -->
      <div x-show="view==='tasks' && clock.clockIn && !clock.clockOut" x-cloak class="p-4 border-t border-ink-200 bg-surface shrink-0">
        <div x-show="blocking.length" x-cloak class="rounded-lg bg-warning-50 ring-1 ring-warning-100 p-2.5 mb-2.5">
          <p class="text-[12px] font-semibold text-warning-800 flex items-center gap-1.5">${icon('alert', 'w-3.5 h-3.5')}<span x-text="blocking.length+' required task'+(blocking.length>1?'s':'')+' before clock-out'"></span></p>
          <p class="text-[11px] text-warning-700 mt-0.5" x-text="blocking.map(t=>t.title).join(', ')"></p>
        </div>
        <button @click="confirmClockOut()" :disabled="!canClockOut" class="btn btn-lg w-full" :class="canClockOut ? 'btn-primary' : 'btn-secondary opacity-60'">
          ${icon('check-circle', 'w-5 h-5')}<span x-text="canClockOut ? 'Complete visit & clock out' : 'Record required tasks first'"></span>
        </button>
      </div>
      <div x-show="view==='tasks' && clock.clockOut" x-cloak class="p-4 border-t border-ink-200 bg-success-50 shrink-0 text-center">
        <p class="text-sm font-semibold text-success-700 flex items-center justify-center gap-1.5">${icon('check-circle', 'w-4 h-4')}Visit completed — clocked out <span x-text="clock.clockOut"></span></p>
      </div>
    </div>`

  return page(html`
    ${pageHeader({ breadcrumbs: [{ label: 'Carer App', href: '#/carer' }, { label: `${v} visit` }], title: 'Carer visit', subtitle: 'Clock in, record evidence against each task, and clock out. State persists across reloads.' })}
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
      ${phone(inner)}
      <div class="space-y-4 max-w-md hidden lg:block">
        ${sectionCard({ title: 'Try it', icon: 'sparkles', body: html`<ol class="space-y-2.5 text-sm text-ink-600 list-decimal pl-4">
          <li>Tap <b>Clock in</b> to start the visit.</li>
          <li>Open <b>Prompt morning medication</b> — record the eMAR outcome (required).</li>
          <li>Open <b>Check pressure areas</b> — mark the body map and raise a concern.</li>
          <li>Try <b>Clock out</b> before finishing required tasks — it’s blocked and tells you what’s left.</li>
          <li>Reload the page — your records are still there.</li>
        </ol>` })}
        ${sectionCard({ title: 'Essential features', icon: 'check-circle', body: html`<div class="grid grid-cols-2 gap-2 text-[13px] text-ink-600">
          ${map(['Clock in / out', 'Required-task gating', 'eMAR outcomes', 'Schema-driven forms', 'Field validation', 'Refusal / reason codes', 'Body map marking', 'Signature capture', 'Raise concern → alert', 'Visit handover note', 'Offline + sync', 'Persisted state'], (f) => `<span class="flex items-center gap-1.5">${icon('check', 'w-3.5 h-3.5 text-success-600')}${f}</span>`)}
        </div>` })}
      </div>
    </div>
  `)
}
