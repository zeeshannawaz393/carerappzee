/** Service users with personalised task plans and active risks. */
export const SERVICE_USERS = [
  {
    id: 'su-mary', name: 'Mary Adams', initials: 'MA', dob: '1939-04-12', age: 87,
    nhs: '485 777 3456', address: '14 Elm Court, Riverside', package: 'Domiciliary — 4 visits/day',
    keyContact: 'Daughter — Susan Adams', gp: 'Riverside Medical Practice', color: 'primary',
    risks: ['Dehydration risk', 'Falls risk', 'Pressure ulcer risk'],
    flags: ['Diabetes', 'Early dementia'], activeTaskCount: 11, openExceptions: 3,
    startedCare: '2025-11-03',
    allergies: ['Penicillin', 'Elastoplast'],
    access: 'Key safe by front door — code on carer profile',
    aboutMe: 'Former primary-school teacher. Hard of hearing on the left — approach from the right. Likes Radio 2, tea with milk (no sugar) and orange squash. Prefers female carers for personal care.',
    emergencyContact: 'Susan Adams (daughter) · 07700 900112',
    dnacpr: false,
  },
  { id: 'su-george', name: 'George Bell', initials: 'GB', dob: '1945-08-30', age: 80, nhs: '485 222 1190', address: '3 Oak Lane', package: 'Domiciliary — 2 visits/day', keyContact: 'Son — Peter Bell', gp: 'Parkside Surgery', color: 'teal', risks: ['Falls risk'], flags: ['COPD'], activeTaskCount: 6, openExceptions: 1, startedCare: '2026-01-19' },
  { id: 'su-doris', name: 'Doris Finch', initials: 'DF', dob: '1937-02-04', age: 89, nhs: '485 909 7781', address: '22 Willow Way', package: 'Domiciliary — 3 visits/day', keyContact: 'Niece — Karen Finch', gp: 'Riverside Medical Practice', color: 'warning', risks: ['Moving & handling — high risk', 'Pressure ulcer risk'], flags: ['Hoist transfer', 'Catheter'], activeTaskCount: 9, openExceptions: 2, startedCare: '2025-09-12' },
  { id: 'su-harold', name: 'Harold Price', initials: 'HP', dob: '1942-11-21', age: 83, nhs: '485 444 6655', address: '8 Maple Drive', package: 'Palliative — 4 visits/day', keyContact: 'Wife — Edith Price', gp: 'Parkside Surgery', color: 'danger', risks: ['End of life', 'Pressure ulcer risk'], flags: ['Palliative', 'Syringe driver'], activeTaskCount: 8, openExceptions: 0, startedCare: '2026-05-28' },
]

export function getServiceUser(id) {
  return SERVICE_USERS.find((s) => s.id === id)
}
